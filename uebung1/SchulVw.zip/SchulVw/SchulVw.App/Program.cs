﻿using SchulVw.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchulVw.App
{
    class Program
    {
        static void Main(string[] args)
        {
            /* INITIALIZER */
            Schule s = new Schule() { Skz = 905417, Name = "HTL Spengergasse" };
            s.AddKlasse(new Klasse() { Name = "5CHIF" });
        }
    }
}
